
*Project information:
  - .Net Framework 4.7.2

*Instructions to use the app:
 1- Add a function (term by term).
 2- Add Min and Max values for X.
 3- Click Draw button.
 4- To clear the current whole function, push Clear button. Then add the new function (term by term).
 
  # To add a function, enter the function term by term. 
      Ex.: 3*X^2 + 1*X
	1- Enter coefficient 3, then enter pow 2, then push Add Term button. Then add the other term.
	2- For constants, add constant in coefficient box, then use 0 in power box.
	3- Use big Min and Max ranges  ex.:  -100 to 100, but not too big.

Note:  - Please, START by using simple functions, like the previous one. Then use more complex ones like with fraction powers.
            - For fraction powers ex.: 1/n or -1/n, use only positive Min and Max.  IT IS NOT  A COMPLETE TASK .