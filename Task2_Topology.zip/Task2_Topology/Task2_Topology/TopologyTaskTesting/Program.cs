﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TopologyAPI;
using Task2_Topology.Topology;

namespace TopologyTaskTesting
{
    class Program
    {
        static void Main(string[] args)
        {
            API api = new API();
            api.fillJsonFile();

            var topologies = api.queryTopologies();
            
            topologies.ForEach(elem =>  Console.WriteLine(elem.Id) );

            api.deleteTopology(1);
            topologies = api.queryTopologies();
            topologies.ForEach(elem => Console.WriteLine(elem.Id));
        }
    }
}
