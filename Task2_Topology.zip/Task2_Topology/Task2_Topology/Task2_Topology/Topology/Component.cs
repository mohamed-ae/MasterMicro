﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2_Topology.Topology
{
    public class Component
    {
        public string Type { get; set; }
        public uint Id { get; set; }

        // This is a simple representation of Netlist, because I do not understand what it means
        public bool IsNetlistConnected { get; set; }
    }

    public class Device1:Component
    {

    }

    public class Device2:Component
    {

    }



    public class Topology
    {
        public Topology()
        {
            Components = new List<Component>();
        }

        public uint Id { get; set; }
        public List<Component> Components { get; private set; }

        public void addComponent(Component comp)
        {
            Components.Add(comp);
        }



    }

}
