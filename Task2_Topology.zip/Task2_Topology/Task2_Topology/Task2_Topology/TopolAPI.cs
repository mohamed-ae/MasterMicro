﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using Task2_Topology.Topology;

namespace TopologyAPI
{

    public class API
    {
        private string path;
        const string fname = "StorageJsonFile.txt";

        public API()
        {
            path = Directory.GetCurrentDirectory() + @"\" + fname;
            File.Create(path).Close();
        }

        // Fill the file with data
        public void fillJsonFile()
        {
            var comp1= new Device1();
            comp1.Id = 1;
            comp1.Type = "Comp1Device1";
            comp1.IsNetlistConnected = true;

            var comp2= new Device1();
            comp2.Id = 2;
            comp2.Type = "Comp2Device1";
            comp2.IsNetlistConnected = false;

            Topology top1 = new Topology();
            top1.Id = 1;
            top1.addComponent(comp1);
            top1.addComponent(comp2);

            var comp3 = new Device2();
            comp3.Id = 3;
            comp3.Type = "Comp3Device2";
            comp3.IsNetlistConnected = false;

            var comp4 = new Device2();
            comp4.Id = 4;
            comp4.Type = "Comp4Device2";
            comp4.IsNetlistConnected = true;

            Topology top2 = new Topology();
            top2.Id = 2;
            top2.addComponent(comp3);
            top2.addComponent(comp4);

            List<Topology> topologies = new List<Topology>();
            topologies.Add(top1);
            topologies.Add(top2);

            string txt = JsonConvert.SerializeObject(topologies);
            File.WriteAllText(path, txt);
        }

        public void addTopology(Topology topology)
        {
            /*
                This is a bad-performance way of reading/writing data, but this is all I know at the moment
            */

            // read from the file then Deserialize
            string txt = File.ReadAllText(fname);
            List<Topology> jsonObj = JsonConvert.DeserializeObject<List<Topology>>(txt);

            // add new topology then Serialize
            jsonObj.Add(topology);
            string jsonStr = JsonConvert.SerializeObject(topology);

        }

        public Topology getTopology(uint id)
        {
            // read from the file and then Deserialize
            string txt = File.ReadAllText(fname);
            Topology topology = JsonConvert.DeserializeObject<List<Topology>>(txt).Where(elem => elem.Id == id).Single();

            return topology;
        }

        public List<Topology> queryTopologies()
        {

            // read from the file and Deserialize
            string txt = File.ReadAllText(fname);
            List<Topology> topologies = JsonConvert.DeserializeObject<List<Topology>>(txt);
            
            return topologies;
        }

        public void deleteTopology(uint id)
        {
            // first reading the file and Deserialize
            string txt = File.ReadAllText(fname);
            List<Topology> topologies = JsonConvert.DeserializeObject<List<Topology>>(txt);
            topologies.Remove(topologies.Where(elem => elem.Id == id).Single());

            // second Serialize and write back to the file
            string jsonStr = JsonConvert.SerializeObject(topologies);
            File.WriteAllText(path, jsonStr);
        }

        public List<Component> queryDevices(uint id)
        {
            // read from the file then Deserialize
            string txt = File.ReadAllText(fname);
            List<Topology> topologies = JsonConvert.DeserializeObject<List<Topology>>(txt);

            // extract devices of that topology's id
            List<Component> devices = topologies.Where(elem => elem.Id == id).Single().Components;

            return devices;
        }

        public List<Component> queryDevicesWithNetlistNode()
        {
            // read from the file then Deserialize
            string txt = File.ReadAllText(fname);
            List<Topology> topologies = JsonConvert.DeserializeObject<List<Topology>>(txt);

            // extract devices from inside topologies
            List<Component> devices = new List<Component>();
            topologies.ForEach(elem => devices.AddRange(elem.Components.FindAll(comp => comp.IsNetlistConnected)));

            return devices;
        }


    }

    


}
