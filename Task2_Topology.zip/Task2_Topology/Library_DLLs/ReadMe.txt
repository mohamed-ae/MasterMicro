 This is the built DLL of the Topology project + the DLL for Newtonsoft.Json package
